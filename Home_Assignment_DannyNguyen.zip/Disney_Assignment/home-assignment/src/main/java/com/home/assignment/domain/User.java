package com.home.assignment.domain;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * User entity bean
 * @author Danny Nguyen
 *
 */
@Entity
@Table (name = "USERS")
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {

	@Id	
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="users_generator")
	@SequenceGenerator(name="users_generator", sequenceName="USERS_SEQ", allocationSize=1)
	private Long Id;
	private String userName;
	private String phone;
	
	@ManyToMany(mappedBy = "users")
    private Set<Event> events;
	
	public User() {
		super();
	}
	
	public User(String userName, String phone) {
		this.userName = userName;
		this.phone = phone;
	}
	
	public Long getId() {
		return Id;
	}

	public void setId(Long Id) {
		this.Id = Id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	@Override
    public String toString() {
        return "User value {" +
                "id =" + Id +
                ", userName ='" + userName + '\'' +
                ", phone ='" + phone + '\'' +
                '}';
    }

	public Set<Event> getEvents() {
		return events;
	}

	public void setEvents(Set<Event> events) {
		this.events = events;
	}	
}
