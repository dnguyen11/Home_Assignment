package com.home.assignment.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.home.assignment.domain.Event;
import com.home.assignment.domain.User;
import com.home.assignment.repository.EventRepository;

/**
 * Rest Controller to register users for an event and get all users for an event
 * @author Danny Nguyen
 *
 */
@RestController
@RequestMapping("/api")
public class UserEventController {

	@Autowired
	EventRepository eventRepository;
	
	/**
	 * Service to register user with the given event by event id
	 * @param id the id of event
	 * @param user the user to be registered with the event
	 * @return event with all registered users
	 */
	@RequestMapping(value = "/events/{id}/users", method = RequestMethod.POST)
    public Event registerUserForEvent(@PathVariable("id") long id, @RequestBody User user) {

		Event currentEvent = eventRepository.getOne(id);
		currentEvent.getUsers().add(user);
		eventRepository.save(currentEvent);
		
		return currentEvent;
	}
	
	/**
	 * Service to find all users for an event by given event id
	 * @param id id of the event
	 * @return set of users
	 */
	@RequestMapping(value = "/events/{id}/users", method = RequestMethod.GET)
    public Set<User> getUsersForEvent(@PathVariable("id") long id) {

		Event currentEvent = eventRepository.getOne(id);
		return currentEvent.getUsers();
	}
}
