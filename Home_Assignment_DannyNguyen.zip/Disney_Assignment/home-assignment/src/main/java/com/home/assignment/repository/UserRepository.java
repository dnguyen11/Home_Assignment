package com.home.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.home.assignment.domain.User;

/**
 * User repository
 * @author Danny Nguyen
 *
 */
public interface UserRepository extends JpaRepository<User, Long> {

}
