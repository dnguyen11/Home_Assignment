package com.home.assignment.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Event entity bean
 * @author Danny Nguyen
 *
 */
@Entity
@Table(name = "EVENTS")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Event {
	
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="events_generator")
	@SequenceGenerator(name="events_generator", sequenceName="EVENTS_SEQ", allocationSize = 1)
	private Long Id;
	private String eventName;
	private Date eventDatetime;
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "USERS_EVENTS", joinColumns = { @JoinColumn(name = "EVENT_ID", referencedColumnName = "id") }, 
		inverseJoinColumns = { @JoinColumn(name = "USER_ID", referencedColumnName = "id") })
	private Set<User> users = new HashSet<User>();
	
	public Event() {
		super();
	}
	
	public Event(String eventName, Date eventDatetime) {
		this.eventName = eventName;
		this.eventDatetime = eventDatetime;
	}
	
	public Long getId() {
		return Id;
	}

	public void setId(Long Id) {
		this.Id = Id;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Date getEventDatetime() {
		return eventDatetime;
	}
	public void setEventDatetime(Date eventDatetime) {
		this.eventDatetime = eventDatetime;
	}
	
	@Override
    public String toString() {
        return "Event value {" +
                "id =" + Id +
                ", eventName ='" + eventName + '\'' +
                ", eventDatetime ='" + eventDatetime + '\'' +
                '}';
    }

	public Set<User> getUsers() {
		return users;
	}

	public void setUsers(Set<User> users) {
		this.users = users;
	}
}
