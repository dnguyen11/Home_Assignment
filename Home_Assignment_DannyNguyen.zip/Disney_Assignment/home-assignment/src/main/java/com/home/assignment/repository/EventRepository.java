package com.home.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.home.assignment.domain.Event;

/**
 * Event repository
 * @author Danny Nguyen
 *
 */
public interface EventRepository extends JpaRepository<Event, Long> {

}
