package com.home.assignment.test.client;

import java.net.URI;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.home.assignment.domain.Event;

import static org.junit.Assert.assertEquals;

/**
 * Tests CRUD Rest APIs for Event.
 * @author Danny Nguyen
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class EventRestAPIsITest {

	private static final Logger log = LoggerFactory.getLogger(EventRestAPIsITest.class);
	
	@Test
	public void testEventCRUDRestApis() {
		
		String REST_SERVICE_URI = "http://localhost:8080/api";		
        RestTemplate restTemplate = new RestTemplate();

        // Test create an event
        Event event = new Event("Event 1", new Date());
        URI uri = restTemplate.postForLocation(REST_SERVICE_URI + "/events/", event, Event.class);
        String addedLocation = uri.toASCIIString();

        log.info("Location : " + addedLocation);
        int addedEventId = 1;
        try {
        	// get newly added event id from return location e.g. http://localhost:8080/api/events/1
        	addedEventId = Integer.valueOf(addedLocation.substring(33));

        } catch (Exception e) {
        	log.error("Cannot get new event id: ", e);
        }
        
        log.info("Location : " + uri.toASCIIString());
        
        // Test get an event by id
        Event event1 = restTemplate.getForObject(REST_SERVICE_URI + "/events/" + addedEventId, Event.class);
        log.info(event1.toString());
        
        assertEquals("Event 1", event1.getEventName());
        
        if (event1 != null) {
	        // Test update an event
	        event1.setEventName("Now becomes event 2");
	        restTemplate.put(REST_SERVICE_URI + "/events/" + event1.getId(), event1);
        }
        
        // Test get an event by id after an update
        event1 = restTemplate.getForObject(REST_SERVICE_URI + "/events/" + event1.getId(), Event.class);
        log.info(event1.toString());
        assertEquals("Now becomes event 2", event1.getEventName());
        
        // Test create more events
        Event event3 = new Event("Event 3", new Date());
        restTemplate.postForLocation(REST_SERVICE_URI + "/events/", event3, Event.class);
        
        Event event4 = new Event("Event 4", new Date());
        restTemplate.postForLocation(REST_SERVICE_URI + "/events/", event4, Event.class);
        
        Event event5 = new Event("Event 5", new Date());
        URI uri5 = restTemplate.postForLocation(REST_SERVICE_URI + "/events/", event5, Event.class);
     	
        String location5 = uri5.toASCIIString();
        int eventId5 = 1;
        try {
        	// get newly added event id from return location e.g. http://localhost:8080/api/events/1
        	eventId5 = Integer.valueOf(location5.substring(33));

        } catch (Exception e) {
        	log.error("Cannot get event id: ", e);
        }
        // Test delete an event
        restTemplate.delete(REST_SERVICE_URI + "/events/" + eventId5);
	}
}
