package com.home.assignment.test.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.net.URI;
import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.hateoas.hal.Jackson2HalModule;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.home.assignment.domain.Event;
import com.home.assignment.domain.User;


/**
 * Tests CRUD Rest APIs for User.
 * @author Danny Nguyen
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class UserRestAPIsTest {

	private static final Logger log = LoggerFactory.getLogger(UserRestAPIsTest.class);
	
	@Test
	public void testUserCRUDRestApis() {
		
		String REST_SERVICE_URI = "http://localhost:8080/api";
        RestTemplate restTemplate = new RestTemplate();
        
        // Test create a user
        User user = new User("User 1", "610-000-3333");
        URI uri = restTemplate.postForLocation(REST_SERVICE_URI + "/users/", user, User.class);
        String addedLocation = uri.toASCIIString();

        log.info("Location : " + addedLocation);
        int addedUserId = 1;
        try {
        	// get newly added user id from return location e.g. http://localhost:8080/api/users/1
        	addedUserId = Integer.valueOf(addedLocation.substring(32));

        } catch (Exception e) {
        	log.error("Cannot get new user id: ", e);
        }

	    // Test get a user by id
        User user1 = restTemplate.getForObject(REST_SERVICE_URI + "/users/" + addedUserId, User.class);
	    log.info("Found user: " + user1.toString());        
        
	    assertEquals("User 1", user1.getUserName());
	    
	    if (user1 != null) {
	        // Test update a user
	    	user1.setUserName("Now becomes user 2");
	        restTemplate.put(REST_SERVICE_URI + "/users/" + user1.getId(), user1);
        }
	    
	    // Test get a user by id after an update
        user1 = restTemplate.getForObject(REST_SERVICE_URI + "/users/" + user1.getId(), User.class);
	    log.info("Found user: " + user1.toString());        
        
	    assertEquals("Now becomes user 2", user1.getUserName());
	    
	    // Get all users in the system
	    ObjectMapper mapper = new ObjectMapper();
 		mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
 		mapper.registerModule(new Jackson2HalModule());

 		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
 		converter.setSupportedMediaTypes(MediaType.parseMediaTypes("application/hal+json"));
 		converter.setObjectMapper(mapper);

 		RestTemplate halRestTemplate = new RestTemplate(Collections.<HttpMessageConverter<?>> singletonList(converter));
 		
 		List<User> systemUsersList = halRestTemplate.getForObject(REST_SERVICE_URI+"/users", List.class);
 		assertNotNull(systemUsersList);
     	assertTrue(systemUsersList.size() == 1);

	    // Test get an event
	    Event event1 = restTemplate.getForObject(REST_SERVICE_URI+"/events/1", Event.class);
	    log.info(event1.toString());
        

	    // Register user for an event  
	    event1 = restTemplate.postForObject(REST_SERVICE_URI+"/events/" + event1.getId() + "/users", user1, Event.class);        
	    log.info(event1.toString());
	    
	    // Get all users for an event
	    String usersEventString = restTemplate.getForObject(REST_SERVICE_URI+"/events/" + event1.getId() + "/users", String.class);
	    
	    try {
	    	
	    	List<User> userList = mapper.readValue(usersEventString, TypeFactory.defaultInstance().constructCollectionType(List.class, User.class));
	    	assertNotNull(userList);
	    	assertTrue(userList.size() == 1);
	    	
	    	userList.forEach(u -> log.info("User from event" + u.toString()));
	    		
	    } catch (Exception e) {
	    	
	    	log.error("Cannot convert to User object from JSon string: ", e);
	    }
	}
}
