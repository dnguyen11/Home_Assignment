-- events table
CREATE TABLE events
( 
  id number NOT NULL,
  event_name varchar2(80) NOT NULL,
  event_datetime timestamp,
  CONSTRAINT events_pk PRIMARY KEY (id)
);

-- users table
CREATE TABLE users
( 
  id number NOT NULL,
  user_name varchar2(80) NOT NULL,
  phone varchar2(30),
  CONSTRAINT users_pk PRIMARY KEY (id)
);

-- users_events table.  This table contains the users and events links
CREATE TABLE users_events
( 
  user_id number NOT NULL,
  event_id number NOT NULL,
  CONSTRAINT fk_users
      FOREIGN KEY (user_id)
      REFERENCES users(id),
  CONSTRAINT fk_events
      FOREIGN KEY (event_id)
      REFERENCES events(id)
);

-- events sequence
CREATE SEQUENCE events_seq
 START WITH     1
 INCREMENT BY   1;
 
-- users sequence
CREATE SEQUENCE users_seq
 START WITH     1
 INCREMENT BY   1; 
